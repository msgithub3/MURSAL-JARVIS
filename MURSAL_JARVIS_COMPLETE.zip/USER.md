# USER.md — MURSAL JARVIS User Profile & Preferences

Generated: 2026-09-09T11:37:09.576Z

### user_identity
- Commander Mursaleen

### communication_style
- Prefers Pakistani conversational style (Urdu, Roman Urdu, English) with natural respectful warmth ("jani", "yaar", "theek hai").

### favorite_city
- Lahore, Pakistan

### pref-lang
- User prefers Roman Urdu

### sync-dedup-1
- User favorite color is Blue

### user_preference
- Prefers Roman Urdu and English

### coffee_pref
- Prefers Kashmiri Chai with almond
