export type JarvisPhase =
  | 'STANDBY'
  | 'WAKE_WORD_DETECTED'
  | 'LISTENING_FOR_COMMAND'
  | 'TRANSCRIBING'
  | 'THINKING'
  | 'TOOL_EXECUTION'
  | 'SPEAKING';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis' | 'system';
  text: string;
  image?: string;
  timestamp: number;
  intent?: string;
  toolsUsed?: string[];
  isAudioPlaying?: boolean;
  engineMode?: string;
  quotaWarning?: string;
}

export interface MetricItem {
  name: string;
  score: number;
  status: string;
  note: string;
}

export interface SourcingChannel {
  name: string;
  availability: string;
  estimatedCost: string;
  deliveryDays: string;
}

export interface MursalCartEvaluation {
  productName: string;
  category: string;
  platform: string;
  financials: {
    supplierPrice: number;
    shippingCost: number;
    sellingPrice: number;
    grossProfit: number;
    grossMargin: string;
    estimatedReturnRate: string;
    netEstimatedProfitPKR: number;
  };
  overallScore: number;
  recommendation: string;
  metrics: MetricItem[];
  pakistaniSourcingChannels: SourcingChannel[];
}

export interface MeshDevice {
  id: string;
  name: string;
  type: 'android_phone' | 'cloud_server' | 'laptop' | 'tablet';
  status: 'online' | 'standby' | 'disconnected';
  battery: number;
  network: string;
  lastLocation: { lat: number; lng: number; label: string };
  lastHeartbeat: number;
  isLocked: boolean;
}

export interface AuditLog {
  id: string;
  event: string;
  device: string;
  timestamp: number;
  level: string;
}

export interface MemoryRecord {
  id: string;
  type: 'short_term' | 'long_term' | 'task' | 'tool';
  category: string;
  content: string;
  timestamp: number;
}

export type LanguageMode = 'auto' | 'en' | 'ur' | 'ur-Roman' | 'pa' | 'skr' | 'ps' | 'sd';

export type VoiceProfile = 'classic' | 'calm' | 'friendly' | 'professional' | 'energetic' | 'deep';

export type ResponseStyle = 'natural' | 'friendly' | 'professional' | 'concise' | 'detailed';

export interface JarvisSettings {
  languageMode: LanguageMode;
  voiceLanguage: LanguageMode;
  voiceProfile: VoiceProfile;
  responseStyle: ResponseStyle;
  wakeWord: string;
  autoListen: boolean;
  bargeInEnabled: boolean;
  sensitiveActionConfirmation: boolean;
  speechRate: number;
  speechPitch: number;
}

