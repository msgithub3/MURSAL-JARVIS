import React, { useState, useEffect } from 'react';
import {
  Battery,
  BatteryCharging,
  Flashlight,
  Volume2,
  VolumeX,
  Sun,
  Wifi,
  WifiOff,
  Bluetooth,
  Play,
  Pause,
  SkipForward,
  Bell,
  Smartphone,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Radio,
} from 'lucide-react';
import { DeviceTelemetryState } from '../lib/deviceActionRouter';

interface DeviceControlHUDProps {
  onExecuteAction: (action: string, params?: Record<string, any>, confirmed?: boolean) => Promise<any>;
  onSpeakText?: (text: string) => void;
  langMode?: string;
}

export const DeviceControlHUD: React.FC<DeviceControlHUDProps> = ({
  onExecuteAction,
  onSpeakText,
  langMode = 'ur-Roman',
}) => {
  const [deviceState, setDeviceState] = useState<DeviceTelemetryState | null>(null);
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [sensitivePrompt, setSensitivePrompt] = useState<{ action: string; prompt: string } | null>(null);
  const [notificationOpen, setNotificationOpen] = useState(false);

  // Fetch initial state
  const fetchState = async () => {
    try {
      const res = await fetch('/api/jarvis/device/state');
      if (res.ok) {
        const data = await res.json();
        setDeviceState(data.state);
      }
    } catch (e) {
      console.warn('Failed to fetch device state:', e);
    }
  };

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleAction = async (action: string, params: Record<string, any> = {}, confirmed = false) => {
    setLoadingAction(action);
    try {
      const res = await fetch('/api/jarvis/device/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, params, confirmed }),
      });
      const data = await res.json();
      if (data.result?.requiresConfirmation) {
        setSensitivePrompt({ action, prompt: data.result.confirmationPrompt || 'Jani, ye action thora sensitive hai. Kar doon?' });
      } else {
        setSensitivePrompt(null);
        if (data.currentState) {
          setDeviceState(data.currentState);
        }
        if (onSpeakText && data.result?.message) {
          onSpeakText(data.result.message);
        }
      }
    } catch (e) {
      console.error('Device action failed', e);
    } finally {
      setLoadingAction(null);
    }
  };

  if (!deviceState) {
    return (
      <div className="p-4 rounded-xl bg-[#0f0f13] border border-[#1e1e26] text-xs font-mono text-[#80808a] flex items-center justify-center">
        Connecting to Android Device Subsystems...
      </div>
    );
  }

  return (
    <div id="device-control-hud" className="p-4 rounded-2xl bg-[#0f0f13] border border-[#1e1e26] shadow-lg space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1e1e24] pb-2.5">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="font-mono font-bold text-[#f0f0f5] tracking-wider uppercase">
            Android Hardware & Subsystems Control
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono text-[#71717a]">Mursal Android Pro (Lahore Node)</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </div>
      </div>

      {/* Sensitive Confirmation Alert if active */}
      {sensitivePrompt && (
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 space-y-2">
          <div className="flex items-center gap-2 font-semibold font-mono text-[11px]">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>SENSITIVE ACTION CONFIRMATION</span>
          </div>
          <p className="text-xs text-[#e0e0e0] font-sans">{sensitivePrompt.prompt}</p>
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => handleAction(sensitivePrompt.action, {}, true)}
              className="px-3 py-1 rounded bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-[11px] transition-colors cursor-pointer"
            >
              Han, Kar Do (Confirm)
            </button>
            <button
              onClick={() => setSensitivePrompt(null)}
              className="px-3 py-1 rounded bg-[#1e1e26] hover:bg-[#2a2a38] text-[#c0c0ca] font-mono text-[11px] transition-colors cursor-pointer"
            >
              Cancel (Nahi)
            </button>
          </div>
        </div>
      )}

      {/* Quick Controls Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* Battery Telemetry */}
        <div className="p-3 rounded-xl bg-[#131318] border border-[#1e1e26] flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-[#80808a] block uppercase">Battery</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-bold font-mono text-white">{deviceState.battery.level}%</span>
              <span className="text-[10px] text-emerald-400 font-mono">{deviceState.battery.temperature}°C</span>
            </div>
            <span className="text-[9px] text-[#71717a] font-mono block">Health: {deviceState.battery.health}</span>
          </div>
          {deviceState.battery.isCharging ? (
            <BatteryCharging className="w-6 h-6 text-emerald-400 animate-pulse" />
          ) : (
            <Battery className="w-6 h-6 text-cyan-400" />
          )}
        </div>

        {/* Flashlight / Torch Toggle */}
        <button
          onClick={() => handleAction('control_flashlight')}
          disabled={loadingAction === 'control_flashlight'}
          className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
            deviceState.flashlight
              ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
              : 'bg-[#131318] hover:bg-[#181820] border-[#1e1e26] text-[#c0c0ca]'
          }`}
        >
          <div>
            <span className="text-[10px] font-mono text-[#80808a] block uppercase">Torch / Flashlight</span>
            <span className="text-sm font-bold font-mono mt-0.5 block text-white">
              {deviceState.flashlight ? 'ACTIVE (ON)' : 'OFF'}
            </span>
            <span className="text-[9px] text-[#71717a] font-mono block">Camera Torch API</span>
          </div>
          <Flashlight className={`w-5 h-5 ${deviceState.flashlight ? 'text-amber-400 fill-amber-400 animate-pulse' : 'text-[#71717a]'}`} />
        </button>

        {/* Wi-Fi Toggle */}
        <button
          onClick={() => handleAction('control_wifi')}
          disabled={loadingAction === 'control_wifi'}
          className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
            deviceState.wifi.enabled
              ? 'bg-sky-500/10 border-sky-500/30 text-sky-300'
              : 'bg-[#131318] hover:bg-[#181820] border-[#1e1e26] text-[#80808a]'
          }`}
        >
          <div>
            <span className="text-[10px] font-mono text-[#80808a] block uppercase">Wi-Fi Network</span>
            <span className="text-sm font-bold font-mono mt-0.5 block text-white truncate max-w-[90px]">
              {deviceState.wifi.enabled ? 'Wi-Fi 6' : 'DISABLED'}
            </span>
            <span className="text-[9px] text-[#71717a] font-mono block">{deviceState.wifi.ipAddress}</span>
          </div>
          {deviceState.wifi.enabled ? <Wifi className="w-5 h-5 text-sky-400" /> : <WifiOff className="w-5 h-5 text-red-400" />}
        </button>

        {/* Anti-Loss Siren Locator */}
        <button
          onClick={() => handleAction('ring_device')}
          disabled={loadingAction === 'ring_device'}
          className="p-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 text-left flex items-center justify-between transition-all cursor-pointer"
          title="Sound Anti-Loss acoustic alarm on Android device at maximum volume"
        >
          <div>
            <span className="text-[10px] font-mono text-red-400/80 block uppercase">Anti-Loss Siren</span>
            <span className="text-sm font-bold font-mono mt-0.5 block text-white">LOCATE PHONE</span>
            <span className="text-[9px] text-red-400/60 font-mono block">Max Audio Beacon</span>
          </div>
          <Radio className="w-5 h-5 text-red-400 animate-pulse" />
        </button>
      </div>

      {/* Sliders & Media Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
        {/* Volume Slider */}
        <div className="p-3 rounded-xl bg-[#131318] border border-[#1e1e26] space-y-1.5">
          <div className="flex items-center justify-between text-[#a0a0b0]">
            <div className="flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[10px] font-mono uppercase">Media Volume</span>
            </div>
            <span className="font-mono font-bold text-white text-xs">{deviceState.volume.media}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={deviceState.volume.media}
            onChange={(e) => {
              const val = parseInt(e.target.value, 10);
              setDeviceState({
                ...deviceState,
                volume: { ...deviceState.volume, media: val },
              });
            }}
            onMouseUp={(e) => handleAction('set_volume', { level: parseInt((e.target as HTMLInputElement).value, 10) })}
            onTouchEnd={(e) => handleAction('set_volume', { level: parseInt((e.target as HTMLInputElement).value, 10) })}
            className="w-full accent-cyan-400 h-1.5 bg-[#22222d] rounded-lg cursor-pointer"
          />
        </div>

        {/* Brightness Slider */}
        <div className="p-3 rounded-xl bg-[#131318] border border-[#1e1e26] space-y-1.5">
          <div className="flex items-center justify-between text-[#a0a0b0]">
            <div className="flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] font-mono uppercase">Brightness</span>
            </div>
            <span className="font-mono font-bold text-white text-xs">{deviceState.brightness}%</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={deviceState.brightness}
            onChange={(e) => {
              const val = parseInt(e.target.value, 10);
              setDeviceState({ ...deviceState, brightness: val });
            }}
            onMouseUp={(e) => handleAction('set_brightness', { level: parseInt((e.target as HTMLInputElement).value, 10) })}
            onTouchEnd={(e) => handleAction('set_brightness', { level: parseInt((e.target as HTMLInputElement).value, 10) })}
            className="w-full accent-amber-400 h-1.5 bg-[#22222d] rounded-lg cursor-pointer"
          />
        </div>

        {/* Media Playback Controller */}
        <div className="p-3 rounded-xl bg-[#131318] border border-[#1e1e26] flex items-center justify-between">
          <div className="truncate pr-2">
            <span className="text-[10px] font-mono text-[#80808a] block uppercase">Media Engine</span>
            <span className="text-xs font-bold text-white block truncate">
              {deviceState.mediaPlayback.currentTrack}
            </span>
            <span className="text-[9px] text-[#71717a] block truncate">
              {deviceState.mediaPlayback.artist}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleAction('control_media', { action: 'toggle' })}
              className="p-2 rounded-lg bg-[#1e1e26] hover:bg-[#2a2a38] text-white transition-colors cursor-pointer"
              title={deviceState.mediaPlayback.isPlaying ? 'Pause' : 'Play'}
            >
              {deviceState.mediaPlayback.isPlaying ? (
                <Pause className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Play className="w-3.5 h-3.5 text-white" />
              )}
            </button>
            <button
              onClick={() => handleAction('control_media', { action: 'next' })}
              className="p-2 rounded-lg bg-[#1e1e26] hover:bg-[#2a2a38] text-[#a0a0b0] hover:text-white transition-colors cursor-pointer"
              title="Next Track"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Notifications Drawer Toggle */}
      <div className="pt-1 border-t border-[#1e1e24] flex items-center justify-between">
        <button
          onClick={() => setNotificationOpen(!notificationOpen)}
          className="text-xs font-mono text-[#a0a0b0] hover:text-white flex items-center gap-1.5 cursor-pointer"
        >
          <Bell className="w-3.5 h-3.5 text-purple-400" />
          <span>Status Bar Notifications ({deviceState.recentNotifications.length})</span>
        </button>
        <span className="text-[10px] font-mono text-[#71717a]">
          Last Telemetry Sync: {new Date(deviceState.lastUpdated).toLocaleTimeString()}
        </span>
      </div>

      {notificationOpen && (
        <div className="space-y-1.5 pt-1">
          {deviceState.recentNotifications.map((n, idx) => (
            <div key={`${n.id}-${idx}`} className="p-2 rounded-lg bg-[#14141a] border border-[#1e1e26] flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-purple-400 font-semibold block">{n.app}</span>
                <span className="text-xs font-medium text-white block">{n.title}</span>
                <span className="text-[11px] text-[#a0a0b0] block">{n.body}</span>
              </div>
              <span className="text-[9px] font-mono text-[#71717a] whitespace-nowrap">
                {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
